let video = document.getElementsByTagName("video")[0];
let playPause = document.getElementById("playPause");
let sound = document.getElementById("sound");

$(document).ready(function(){
    $("img").mouseenter(function(){
        $(this).html('<img src="recursos/person-fill.svg" alt="persona" width="32px" height="32px">');
    });

    $("#item1").click(function(){
        $("#panel").slideDown("slow");
    });

    $("figure").mouseenter(function(){
        $(".ampliar").animate({
            height: '+=50px',
            width: '+=50px'
        });
        $(".ocultar").hide();
    });
    $("figure").mouseleave(function(){
        $(".ampliar").animate({
            height: '16px',
            width: '16px'
        });
        $(".ocultar").show();
    });

});

function reproducirPausar(e){
    if (video.paused) {
        video.play()
        playPause.firstElementChild.setAttribute("src", "\Ej2\recursos\play-circle-fill.svg");
    }else{
        video.pause()
        playPause.firstElementChild.setAttribute("src", "Ej2\recursos\play-circle.svg");
    }
}

playPause.addEventListener("click", reproducirPausar);
sound.addEventListener("click", mutearDesmutear);